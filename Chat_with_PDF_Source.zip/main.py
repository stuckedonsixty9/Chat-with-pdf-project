import streamlit as st
from app.pdf_handler import get_pdf_text, get_text_chunks
from app.vector_store import get_vector_store
from app.rag_chain import get_conversational_chain
from dotenv import load_dotenv
import os

# --- PAGE CONFIGURATION ---
st.set_page_config(page_title="Chat with PDF AI", page_icon="🤖", layout="wide")

# --- CUSTOM CSS FOR PREMIUM LOOK ---
st.markdown("""
<style>
    /* Main Background */
    .stApp {
        background: rgb(14,17,23);
        background: linear-gradient(135deg, rgba(14,17,23,1) 0%, rgba(38,39,48,1) 100%);
    }

    /* Sidebar Styling */
    section[data-testid="stSidebar"] {
        background-color: #1E1E28;
    }
    
    /* Header Styling */
    h1 {
        color: #FFFFFF;
        font-family: 'Helvetica', sans-serif;
        font-weight: 700;
        text-align: center;
        text-shadow: 0px 4px 10px rgba(0,0,0,0.5);
    }
    h2, h3 {
        color: #E0E0E0;
    }

    /* Custom Button */
    .stButton>button {
        background: linear-gradient(90deg, #FF4B4B 0%, #FF9068 100%);
        color: white;
        border: none;
        border-radius: 25px;
        padding: 10px 24px;
        font-weight: bold;
        box-shadow: 0px 4px 15px rgba(255, 75, 75, 0.4);
        transition: all 0.3s ease;
    }
    .stButton>button:hover {
        transform: translateY(-2px);
        box-shadow: 0px 6px 20px rgba(255, 75, 75, 0.6);
    }

    /* Success Message */
    .stSuccess {
        background-color: rgba(0, 255, 127, 0.1);
        border: 1px solid #00FF7F;
        border-radius: 10px;
        color: #00FF7F;
    }
</style>
""", unsafe_allow_html=True)

def main():
    load_dotenv(override=True)
    
    # --- HEADER SECTION ---
    st.markdown("<h1>🤖 Chat with PDF <span style='color:#FF4B4B'>Pro</span></h1>", unsafe_allow_html=True)
    st.markdown("<p style='text-align: center; color: #BBBBBB;'>Powered by Google Gemini 2.5 Flash & AI</p>", unsafe_allow_html=True)
    st.write("") # Spacer

    # Helper to handle button clicks (Callback Mock)
    if "trigger_prompt" not in st.session_state:
        st.session_state.trigger_prompt = None

    def set_trigger(text):
        st.session_state.trigger_prompt = text

    # --- SIDEBAR ---
    with st.sidebar:
        st.image("https://cdn-icons-png.flaticon.com/512/4726/4726010.png", width=80) 
        st.title("📂 Document Hub")
        st.markdown("---")
        
        pdf_docs = st.file_uploader("Upload your PDFs", accept_multiple_files=True, type=["pdf"])
        
        if st.button("🚀 Process Documents"):
            with st.spinner("🔮 AI is analyzing your document... this may take a moment."):
                from app.pdf_handler import upload_to_gemini
                if pdf_docs:
                    if "file_handle" in st.session_state:
                        del st.session_state["file_handle"]
                        
                    file_handle = upload_to_gemini(pdf_docs[0])
                    st.session_state["file_handle"] = file_handle
                    st.session_state["chat_mode"] = "vision"
                    st.success("✅ Analysis Complete! You can now chat.")
        
        # New Feature: Quick Actions Sidebar
        if st.session_state.get("file_handle"):
            st.markdown("### ⚡ Quick Actions")
            if st.button("📝 Summarize Document"):
                set_trigger("Provide a detailed summary of the document with key bullet points.")

        # Reset Button
        if st.session_state.get("file_handle") or st.session_state.get("chat_mode"):
            st.markdown("---")
            if st.button("🗑️ Clear & Start New"):
                st.session_state.clear()
                st.rerun()

        st.markdown("---")
        
        # Translation Option
        st.markdown("### 🌐 Output Language")
        language = st.selectbox(
            "Select Language:",
            ["Auto (Same as Question)", "English", "Hindi", "Hinglish (Mix)"],
            index=0
        )
        st.session_state["language"] = language

        st.markdown("### 🛠️ Help")
        st.info("Upload scanned files, handwritten notes, or regular PDFs. The AI uses Vision to understand everything.")
        
        st.markdown("---")
        st.markdown("<p style='text-align: center; color: #888888; font-size: 12px;'>Made with ❤️ by <b>Raghvendra</b></p>", unsafe_allow_html=True)

    # --- CHAT INTERFACE ---
    
    # Session State for Messages
    if "messages" not in st.session_state:
        st.session_state.messages = []

    # Display Chat History
    for message in st.session_state.messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

    # New Feature: Quick Prompts (Chips) above Input
    if st.session_state.get("file_handle"):
        st.markdown("##### 💡 Suggestion Chips:")
        cols = st.columns(4)
        prompts = ["🔍 Explain Key Concepts", "📅 Find Important Dates", "📊 Analyze Data/Table", "👶 Explain like I'm 5"]
        
        for i, p_text in enumerate(prompts):
            with cols[i]:
                if st.button(p_text, key=f"chip_{i}", use_container_width=True):
                    set_trigger(p_text)

    # Determine Active Prompt
    user_input = st.chat_input("Ask a question from the PDF files...")
    
    # Priority: Button Trigger > Text Input
    final_prompt_to_process = None
    
    if st.session_state.trigger_prompt:
        final_prompt_to_process = st.session_state.trigger_prompt
        st.session_state.trigger_prompt = None # Reset immediately
    elif user_input:
        final_prompt_to_process = user_input

    # Logic for Response
    if final_prompt_to_process:
        # Display User Message
        with st.chat_message("user"):
            st.markdown(final_prompt_to_process)
        st.session_state.messages.append({"role": "user", "content": final_prompt_to_process})

        if st.session_state.get("chat_mode") == "vision":
             # Prepare Prompt
             selected_lang = st.session_state.get("language", "Auto")
             backend_prompt = final_prompt_to_process
             
             if "Hindi" in selected_lang:
                 backend_prompt += " (IMPORTANT: Answer ONLY in Hindi language/Devanagari script)"
             elif "Hinglish" in selected_lang:
                 backend_prompt += " (IMPORTANT: Answer in Hinglish - mix of Hindi and English, easy to understand)"
             elif "English" in selected_lang:
                 backend_prompt += " (IMPORTANT: Answer ONLY in English)"

             with st.chat_message("assistant"):
                 with st.spinner("🤖 AI is thinking..."):
                     try:
                         from app.rag_chain import get_gemini_response
                         file_handle = st.session_state["file_handle"]
                         response_text = get_gemini_response(file_handle, backend_prompt)
                         st.markdown(response_text)
                         st.session_state.messages.append({"role": "assistant", "content": response_text})
                     except Exception as e:
                         # Fallback error handling (rag_chain handles most)
                         st.error(f"Error: {e}")

        else:
            st.warning("⚠️ Please upload a PDF and click 'Process Documents' first.")

if __name__ == "__main__":
    main()
