import os
from langchain_community.vectorstores import Chroma
from langchain_community.embeddings import HuggingFaceEmbeddings
# Alternatively use GoogleGenerativeAIEmbeddings if preferred
# from langchain_google_genai import GoogleGenerativeAIEmbeddings

def get_vector_store(text_chunks):
    """
    Creates a Chroma vector store from text chunks using HuggingFace embeddings.
    """
    # Using a local model for embeddings to save API costs and speed up
    embeddings = HuggingFaceEmbeddings(model_name="all-MiniLM-L6-v2")
    
    vector_store = Chroma.from_texts(texts=text_chunks, embedding=embeddings)
    return vector_store
