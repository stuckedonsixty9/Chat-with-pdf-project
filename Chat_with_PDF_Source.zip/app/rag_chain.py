import google.generativeai as genai
import time
import os
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnablePassthrough
from langchain_core.output_parsers import StrOutputParser
from langchain_google_genai import ChatGoogleGenerativeAI
from dotenv import load_dotenv

load_dotenv()

# --- VISION / CHAT MODE (Primary) ---
def get_gemini_response(file_handle, user_question, chat_history=[]):
    """
    Interacts with Gemini 2.5 Flash using the environment API key.
    """
    try:
        api_key = os.getenv("GOOGLE_API_KEY")
        if not api_key:
             return "⚠️ **Error:** GOOGLE_API_KEY not found in environment variables."

        genai.configure(api_key=api_key)
        
        # Initialize Model (Gemini 2.5 Flash)
        model = genai.GenerativeModel("gemini-2.5-flash")
        
        # Prepare Context
        history = [
            {"role": "user", "parts": [file_handle, "Analyze this document and answer questions based on it."]},
            {"role": "model", "parts": ["Understood. I have processed the document. Ask me anything."]}
        ]
        
        # Attempt Chat
        chat = model.start_chat(history=history)
        response = chat.send_message(user_question)
        return response.text
        
    except Exception as e:
        return f"⚠️ **Error:** {str(e)}"

# --- LEGACY MODE (Vector Store) ---
def get_conversational_chain():
    """
    Returns a QA chain. Uses the primary key for simplicity.
    """
    prompt_template = """
    Answer the question as detailed as possible from the provided context.
    Context:
    {context}
    Question: 
    {question}
    Answer:
    """
    
    # Legacy mode key usage
    api_key = os.getenv("GOOGLE_API_KEY")
    if not api_key:
        raise ValueError("GOOGLE_API_KEY not found.")
    model = ChatGoogleGenerativeAI(model="gemini-2.5-flash", temperature=0.3, google_api_key=api_key)
    prompt = PromptTemplate(template=prompt_template, input_variables=["context", "question"])
    chain = prompt | model | StrOutputParser()
    return chain
